CREATE DATABASE IF NOT EXISTS my_card CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE my_card;

CREATE TABLE IF NOT EXISTS admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS profile (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    profession VARCHAR(150),
    bio TEXT,
    photo VARCHAR(255),
    location VARCHAR(255),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS phones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    phone VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS emails (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) NOT NULL
);

CREATE TABLE IF NOT EXISTS social_media (
    id INT AUTO_INCREMENT PRIMARY KEY,
    platform VARCHAR(100) NOT NULL,
    url VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS bank_accounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bank_name VARCHAR(150) NOT NULL,
    account_name VARCHAR(150) NOT NULL,
    account_number VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY,
    site_title VARCHAR(150) DEFAULT 'My Digital Card',
    theme VARCHAR(30) DEFAULT 'dark'
);

INSERT INTO admin (username, password)
SELECT 'admin', '26f493449b9d525843eb12dc443c26a0d6eed71e5e89eaeeea7da0bb2257f34e'
WHERE NOT EXISTS (SELECT 1 FROM admin WHERE username = 'admin');

INSERT INTO profile (name, profession, bio, photo, location)
SELECT 'Your Name', 'Your Profession', 'Welcome to my digital business card.', '', 'Ethiopia'
WHERE NOT EXISTS (SELECT 1 FROM profile);

INSERT INTO settings (id, site_title, theme)
VALUES (1, 'My Digital Card', 'dark')
ON DUPLICATE KEY UPDATE id=id;
