function copyAccount(value){navigator.clipboard.writeText(value).then(()=>alert("Account number copied!")).catch(()=>alert("Copy failed."));}
async function shareCard(){if(navigator.share){await navigator.share({title:document.title,text:"My Digital Business Card",url:location.href});}else{await navigator.clipboard.writeText(location.href);alert("Card link copied!");}}
function toggleTheme(){document.body.classList.toggle("light");localStorage.setItem("cardTheme",document.body.classList.contains("light")?"light":"dark");}
function saveContact(){const name=document.querySelector("h1")?.innerText||"Contact";const text="BEGIN:VCARD\nVERSION:3.0\nFN:"+name+"\nEND:VCARD";const blob=new Blob([text],{type:"text/vcard"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name.replace(/\s+/g,"_")+".vcf";a.click();URL.revokeObjectURL(a.href);}
if(localStorage.getItem("cardTheme")==="light")document.body.classList.add("light");
