<?php
session_start();
require_once "../config/database.php";
if(!empty($_SESSION["admin_id"])){header("Location: dashboard.php");exit;}
$error="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $u=trim($_POST["username"]??"");$p=$_POST["password"]??"";
    $st=$pdo->prepare("SELECT * FROM admin WHERE username=? LIMIT 1");$st->execute([$u]);$a=$st->fetch();
    if($a && hash_equals($a["password"],hash("sha256",$p))){
        $_SESSION["admin_id"]=$a["id"];$_SESSION["admin_username"]=$a["username"];
        header("Location: dashboard.php");exit;
    } $error="Username or password is incorrect.";
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login</title><link rel="stylesheet" href="admin.css"></head>
<body><div class="box"><div class="logo">🔐</div><h1>Admin Login</h1><p>Manage your digital card</p><?php if($error):?><div class="error"><?=htmlspecialchars($error)?></div><?php endif;?><form method="post"><label>Username</label><input name="username" required><label>Password</label><input type="password" name="password" required><button>Login</button></form><a class="back" href="../index.php">← Public Card</a></div></body></html>
