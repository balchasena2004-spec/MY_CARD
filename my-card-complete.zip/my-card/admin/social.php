<?php require_once "auth.php"; require_once "../config/database.php";
if(isset($_GET["delete"])){$st=$pdo->prepare("DELETE FROM social_media WHERE id=?");$st->execute([(int)$_GET["delete"]]);}
if($_SERVER["REQUEST_METHOD"]==="POST"){$st=$pdo->prepare("INSERT INTO social_media(platform,url) VALUES(?,?)");$st->execute([trim($_POST["platform"]),trim($_POST["url"])]);}
$rows=$pdo->query("SELECT * FROM social_media ORDER BY id DESC")->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Social</title><link rel="stylesheet" href="admin.css"></head><body><div class="box"><h1>Social Media</h1><form method="post"><label>Platform</label><input name="platform" placeholder="Facebook / Telegram / Instagram" required><label>URL</label><input name="url" type="url" required><button>Add Social</button></form><?php foreach($rows as $r):?><p><?=htmlspecialchars($r["platform"])?> — <a class="back" style="display:inline" href="?delete=<?=$r["id"]?>">Delete</a></p><?php endforeach;?><a class="back" href="dashboard.php">← Dashboard</a></div></body></html>
