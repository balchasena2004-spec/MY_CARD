<?php
require_once "config/database.php";
$profile = $pdo->query("SELECT * FROM profile ORDER BY id ASC LIMIT 1")->fetch();
$phones = $pdo->query("SELECT * FROM phones ORDER BY id DESC")->fetchAll();
$emails = $pdo->query("SELECT * FROM emails ORDER BY id DESC")->fetchAll();
$socials = $pdo->query("SELECT * FROM social_media ORDER BY id DESC")->fetchAll();
$banks = $pdo->query("SELECT * FROM bank_accounts ORDER BY id DESC")->fetchAll();
$settings = $pdo->query("SELECT * FROM settings WHERE id=1")->fetch();
if (!$profile) $profile = ['name'=>'Your Name','profession'=>'Your Profession','bio'=>'Welcome to my digital business card.','photo'=>'','location'=>'Ethiopia'];
if (!$settings) $settings = ['site_title'=>'My Digital Card','theme'=>'dark'];
function e($v){ return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($settings['site_title']) ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<main class="page">
<section class="card">
<div class="topbar"><span class="badge">DIGITAL CARD</span><button class="icon-btn" onclick="toggleTheme()">☼</button></div>
<div class="avatar"><?php if(!empty($profile['photo'])): ?><img src="<?= e($profile['photo']) ?>" alt="Profile"><?php else: ?>👤<?php endif; ?></div>
<h1><?= e($profile['name']) ?></h1><p class="profession"><?= e($profile['profession']) ?></p>
<p class="bio"><?= e($profile['bio']) ?></p>
<?php if(!empty($profile['location'])): ?><div class="location">📍 <?= e($profile['location']) ?></div><?php endif; ?>

<div class="actions">
<?php if($phones): ?><a class="action" href="tel:<?= e($phones[0]['phone']) ?>">📞<span>Call</span></a><?php endif; ?>
<?php if($emails): ?><a class="action" href="mailto:<?= e($emails[0]['email']) ?>">✉️<span>Email</span></a><?php endif; ?>
<button class="action" onclick="saveContact()">👤<span>Save</span></button>
<button class="action" onclick="shareCard()">↗<span>Share</span></button>
</div>

<?php if($phones): ?><div class="section"><h2>Phone</h2><?php foreach($phones as $p): ?><a class="row" href="tel:<?= e($p['phone']) ?>">📞 <?= e($p['phone']) ?></a><?php endforeach; ?></div><?php endif; ?>
<?php if($emails): ?><div class="section"><h2>Email</h2><?php foreach($emails as $m): ?><a class="row" href="mailto:<?= e($m['email']) ?>">✉️ <?= e($m['email']) ?></a><?php endforeach; ?></div><?php endif; ?>

<?php if($socials): ?><div class="section"><h2>Social</h2><div class="socials"><?php foreach($socials as $s): ?><a href="<?= e($s['url']) ?>" target="_blank" rel="noopener"><?= e($s['platform']) ?></a><?php endforeach; ?></div></div><?php endif; ?>

<?php if($banks): ?><div class="section"><h2>Bank Accounts</h2><?php foreach($banks as $b): ?><div class="bank"><strong><?= e($b['bank_name']) ?></strong><span><?= e($b['account_name']) ?></span><div class="account"><code><?= e($b['account_number']) ?></code><button onclick="copyAccount('<?= e($b['account_number']) ?>')">Copy</button></div></div><?php endforeach; ?></div><?php endif; ?>

<div class="footer"><a href="admin/login.php">Admin</a></div>
</section>
</main>
<script src="script.js"></script>
</body></html>
