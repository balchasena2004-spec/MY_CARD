MY DIGITAL BUSINESS CARD
========================

Stack: PHP + MySQL + HTML5 + CSS3 + JavaScript
Local path for XAMPP:
C:\xampp\htdocs\my-card

SETUP
-----
1. Start Apache and MySQL in XAMPP.
2. Open http://localhost/phpmyadmin
3. Import database/business_card.sql
4. Open public card:
   http://localhost/my-card/
5. Open admin:
   http://localhost/my-card/admin/login.php

STARTER ADMIN
-------------
Username: admin
Password: MyHome@2026!

IMPORTANT
---------
This starter package uses a SHA-256 hash for the local starter password so the password is not stored as plain text.
Change the password from Admin > Change Password after first login.

The package is designed for local XAMPP development. Before public deployment, add HTTPS, CSRF protection, stronger upload validation, rate limiting, secure database credentials, and production password hashing with PHP password_hash/password_verify.
